export default function ProfilePage() {
  return <h3>INI PROFILE PAGE</h3>
}
