import { getArticleItem } from "@/lib/article"
import styles from "./page.module.css"
import { Suspense } from "react"

async function ArticleDetailContent({ params }) {
  const articleItem = await getArticleItem(params)
  return (
    <article>
      <header>
        <h1>{articleItem?.title || "tidak ada data"}</h1>
        <time dateTime={articleItem?.date || ""}>
          {articleItem?.date || ""}
        </time>
      </header>
    </article>
  )
}

export default function ArticleDetailPage({ params }) {
  const articleSlug = params.slug
  return (
    <main className={styles.main}>
      <Suspense fallback={<>Loading detail page...</>}>
        <ArticleDetailContent params={articleSlug} />
      </Suspense>
    </main>
  )
}
