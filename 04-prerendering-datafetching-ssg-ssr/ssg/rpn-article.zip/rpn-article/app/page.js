import styles from "./page.module.css"
import Link from "next/link"

export default async function Home() {
  return (
    <main className={styles.main}>
      <h2>INI HOME PAGE</h2>
      <div className={styles.welcomeContent}>
        {/* POSTS 1 - 100  */}
        <Link href="/posts/1">
          <button className={styles.btnLink}>Posts</button>
        </Link>
      </div>
    </main>
  )
}
