import { SignOutButton, UserProfile } from "@clerk/nextjs"

export default function ProfilePage() {
  return (
    <div
      style={{
        position: "relative",
        width: "fit-content",
        background: "white",
        zIndex: "10px",
      }}
    >
      <UserProfile />
      <div style={{ position: "absolute", bottom: "10px", right: "10px" }}>
        <SignOutButton />
      </div>
    </div>
  )
}
