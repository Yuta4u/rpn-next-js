import { ReactNode } from "react"

export type TData = {
  id: number
  slug: string
  title: string
  content: string
  date: string
  image: string
}

export interface IData {
  id: number
  slug: string
  title: string
  content: string
  date: string
  image: string
}

export type MyComponentProps = {
  children: ReactNode
}
