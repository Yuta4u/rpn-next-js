import Link from "next/link"
import styles from "./page.module.css"

export async function generateStaticParams() {
  const res = await fetch("https://jsonplaceholder.typicode.com/posts")
  const posts = await res.json()

  return posts.map((post) => ({
    id: post.id.toString(),
  }))
}

const PostPage = async ({ params }) => {
  const { id } = params

  const res = await fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
  const post = await res.json()

  return (
    <div className={styles.content}>
      <div className={styles.divContent}>
        <div>
          <span className={styles.title}>{post.title}</span>
        </div>
        <div className={styles.btnDiv}>
          <Link
            className={styles.link}
            href={id === "1" ? "/" : `/posts/${+id - 1}`}
          >
            {id === "1" ? "Home" : `POSTS ${+id - 1}`}
          </Link>
          <Link
            id="btn-r"
            className={styles.link}
            href={`/posts/${+id + 1}`}
          >{`POSTS ${+id + 1}`}</Link>
        </div>
      </div>
    </div>
  )
}

export default PostPage
