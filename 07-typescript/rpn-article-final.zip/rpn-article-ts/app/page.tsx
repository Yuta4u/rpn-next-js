import logo from "@/assets/rpn-logo.png"
import Image from "next/image"
import Link from "next/link"

export default function HomePage() {
  return (
    <div id="home">
      <Image src={logo.src} alt="rpn-logo" width={50} height={80} />
      <h1>Article Site For The Next Generation</h1>
      <p>
        Next article is here to deliver you all the latest article - concise &
        unbiased!
      </p>

      <p>
        Next article aims to provide you with the latest article in a concise
        and unbiased manner. We strive to deliver the article in a way that is
        easy to understand and to the point. We want to keep you informed
        without overwhelming you with unnecessary information.
      </p>

      <p>
        We employ a team of dedicated dev who are committed to delivering the
        article in a fair and unbiased manner. Our team is passionate about
        keeping you informed and up to date with the latest article.
      </p>

      <p>
        <Link href="/article">Read the latest article</Link>
      </p>
    </div>
  )
}
