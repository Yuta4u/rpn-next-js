import Link from "next/link"

export default function ArticleList({ article }) {
  return (
    <ul className="article-list">
      {article.map((articleItem) => (
        <li key={articleItem.id}>
          <Link href={`/article/${articleItem.slug}`}>
            <img
              src={`/images/article/${articleItem.image}`}
              alt={articleItem.title}
            />
            <span>{articleItem.title}</span>
          </Link>
        </li>
      ))}
    </ul>
  )
}
