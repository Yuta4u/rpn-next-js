import styles from "./page.module.css"

export async function generateStaticParams() {
  const res = await fetch("https://jsonplaceholder.typicode.com/posts")
  const posts = await res.json()

  return posts.map((post) => ({
    id: post.id.toString(),
  }))
}

const PostPage = async ({ params }) => {
  const { id } = params

  const res = await fetch(`https://jsonplaceholder.typicode.com/posts/${id}`)
  const post = await res.json()

  return (
    <div className={styles.content}>
      <div>
        <span>title: </span>
        <span className={styles.title}>{post.title}</span>
      </div>
      <p>{post.body}</p>
    </div>
  )
}

export default PostPage
