import { getArticleItem } from "@/lib/article"
import { TData, IData } from "@/types/type"
import { Suspense } from "react"

async function ArticleDetailContent({ params }) {
  const articleItem: TData = await getArticleItem(params) // Menggunakan Types
  // const articleItem: IData = await getArticleItem(params) // Menggunakan Interface
  return (
    <article id="article-detail">
      <header>
        <img
          src={`/images/article/${articleItem.image}`}
          alt={articleItem.title}
        />
        <h1>{articleItem?.title || "tidak ada data"}</h1>
      </header>
      <div>{articleItem.content}</div>
      <time dateTime={articleItem?.date || ""}>{articleItem?.date || ""}</time>
    </article>
  )
}

export default function ArticleDetailPage({
  params,
}: {
  params: { slug: string }
}) {
  const articleSlug = params.slug
  return (
    <main id="article-detail-main">
      <Suspense fallback={<>Loading detail page...</>}>
        <ArticleDetailContent params={articleSlug} />
      </Suspense>
    </main>
  )
}
