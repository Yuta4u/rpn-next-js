import styles from "./page.module.css"

export default function Article() {
  return <main className={styles.main}>ini article</main>
}
