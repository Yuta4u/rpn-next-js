import styles from "./page.module.css"
import Link from "next/link"

export default async function Home() {
  return (
    <main className={styles.main}>
      <h2>INI HOME PAGE</h2>
      <div className={styles.welcomeContent}>
        <Link href="/article/will-ai-replace-humans">
          <button className={styles.btnLink}>Article AI</button>
        </Link>
      </div>
    </main>
  )
}
