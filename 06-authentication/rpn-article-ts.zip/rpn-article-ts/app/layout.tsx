import { ClerkProvider } from "@clerk/nextjs"
import "./globals.css"
import { MyComponentProps } from "@/types/type"

export const metadata = {
  title: "RPN Article",
  description: "Test",
  keywords: "aaa",
}

export default function RootLayout({ children }: MyComponentProps) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/rpn-logo.jpg" type="image/png" />
      </head>
      <body>
        <div id="page">
          <ClerkProvider>{children}</ClerkProvider>
        </div>
      </body>
    </html>
  )
}
