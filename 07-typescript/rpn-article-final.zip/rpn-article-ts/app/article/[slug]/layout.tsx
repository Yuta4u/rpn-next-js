import Link from "next/link"
import Logo from "@/assets/rpn-logo.png"
import Image from "next/image"
import { getLatestArticle } from "@/lib/article"
import ArticleList from "@/components/article-list"

export default async function Layout({ children, latest }) {
  const latestArticleData = await getLatestArticle()

  return (
    <>
      <div id="article">
        <h2 style={{ display: "flex", alignItems: "center" }}>
          <Link href="/article">Article</Link>
        </h2>
        <Link href="/article">
          <Image
            src={Logo}
            width={50}
            height={50}
            alt="rpn-logo"
            className="hover:cursor-pointer"
          />
        </Link>
      </div>
      <section>{children}</section>
      <hr />
      <h2 style={{ marginBottom: "0.5rem" }}>Latest Article</h2>
      <section>
        <ArticleList article={latestArticleData} />
      </section>
    </>
  )
}
