import "./globals.css"

export const metadata = {
  title: "RPN Article",
  description: "Test",
  keywords: "aaa",
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/rpn-logo.jpg" type="image/png" />
      </head>
      <body>
          <div id="page">{children}</div>
      </body>
    </html>
  )
}
