import { Vlds } from "@/components/vlds"
import { getArticleItem } from "@/lib/article"
import Image from "next/image"
import { Suspense } from "react"

async function ArticleDetailContent({ params }) {
  const articleItem = await getArticleItem(params)

  return (
    <article id="article-detail">
      <header>
        <Image
          id="img-detail-article"
          src={`/images/article/${articleItem.image}`}
          alt={articleItem.title}
          width={200}
          height={200}
          loading="lazy"
        />
        <div
          style={{ width: "100%", display: "flex", justifyContent: "center" }}
        >
          <Vlds
            vlds={[
              articleItem.views,
              articleItem.like,
              articleItem.dislike,
              articleItem.shares,
            ]}
          />
        </div>
      </header>

      <div id="article-detail-content">
        <h2>{articleItem.title}</h2>
        <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
          <div>Posted Date: </div>
          <h6>{articleItem.date}</h6>
        </div>
        <div
          style={{
            display: "flex",
            gap: "0.5rem",
            height: "auto",
            flexWrap: "wrap",
          }}
        >
          <div>Tags: </div>
          {articleItem.categories.split("/").map((_: any, idx: number) => (
            <div
              key={idx}
              style={{
                textTransform: "uppercase",
                padding: "2px 5px",
                border: "1px solid white",
                fontSize: "10px",
              }}
            >
              {_}
            </div>
          ))}
        </div>
        <div>{articleItem.content}</div>
      </div>
    </article>
  )
}

export default function ArticleDetailPage({ params }) {
  const articleSlug = params.slug

  return (
    <main id="article-detail-main">
      <Suspense fallback={<>Loading detail article...</>}>
        <ArticleDetailContent params={articleSlug} />
      </Suspense>
    </main>
  )
}
