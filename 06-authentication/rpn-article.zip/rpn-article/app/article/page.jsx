import { getAllArticle } from "@/lib/article"
import ArticleList from "@/components/article-list"
import Link from "next/link"

export default function Article() {
  const articleData = getAllArticle()
  return (
    <div>
      <div id="article">
        <h2>
          <Link href="/">Article</Link>
        </h2>
        <h2 id="profile">
          <Link href="/profile">Profile</Link>
        </h2>
      </div>
      <ArticleList article={articleData} />
    </div>
  )
}
