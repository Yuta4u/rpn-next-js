import { SignOutButton } from "@clerk/nextjs"

export default function ProfilePage() {
  return (
    <>
      <h3>INI PROFILE PAGE</h3>
      <SignOutButton redirectUrl="/article" />
    </>
  )
}
