export function Vlds({ vlds: [views, like, dislike, share] }) {
  return (
    <div style={{ display: "flex", gap: "1rem" }}>
      {/* views  */}
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          textAlign: "center",
          width: "fit-content",
        }}
      >
        <svg
          width="40"
          height="40"
          viewBox="0 0 512 512"
          xmlns="http://www.w3.org/2000/svg"
          className="h-full w-full"
        >
          <rect
            width="40"
            height="40"
            x="0"
            y="0"
            rx="30"
            fill="transparent"
            stroke="transparent"
            strokeWidth="0"
            strokeOpacity="100%"
            paintOrder="stroke"
          ></rect>
          <svg
            width="256px"
            height="256px"
            viewBox="0 0 24 24"
            fill="#ffffff"
            x="128"
            y="128"
            role="img"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g fill="#ffffff">
              <g fill="currentColor" fillRule="evenodd" clipRule="evenodd">
                <path d="M8.25 12a3.75 3.75 0 1 1 7.5 0a3.75 3.75 0 0 1-7.5 0ZM12 9.75a2.25 2.25 0 1 0 0 4.5a2.25 2.25 0 0 0 0-4.5Z" />
                <path d="M4.323 10.646c-.419.604-.573 1.077-.573 1.354c0 .277.154.75.573 1.354c.406.583 1.008 1.216 1.77 1.801C7.62 16.327 9.713 17.25 12 17.25s4.38-.923 5.907-2.095c.762-.585 1.364-1.218 1.77-1.801c.419-.604.573-1.077.573-1.354c0-.277-.154-.75-.573-1.354c-.406-.583-1.008-1.216-1.77-1.801C16.38 7.673 14.287 6.75 12 6.75s-4.38.923-5.907 2.095c-.762.585-1.364 1.218-1.77 1.801Zm.856-2.991C6.91 6.327 9.316 5.25 12 5.25s5.09 1.077 6.82 2.405c.867.665 1.583 1.407 2.089 2.136c.492.709.841 1.486.841 2.209c0 .723-.35 1.5-.841 2.209c-.506.729-1.222 1.47-2.088 2.136c-1.73 1.328-4.137 2.405-6.821 2.405s-5.09-1.077-6.82-2.405c-.867-.665-1.583-1.407-2.089-2.136C2.6 13.5 2.25 12.723 2.25 12c0-.723.35-1.5.841-2.209c.506-.729 1.222-1.47 2.088-2.136Z" />
              </g>
            </g>
          </svg>
        </svg>
        <div style={{ fontSize: "12px" }}>{views}</div>
        <div style={{ fontSize: "12px", fontStyle: "italic" }}>Views</div>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          textAlign: "center",
          width: "fit-content",
        }}
      >
        <svg
          width="40"
          height="40"
          viewBox="0 0 512 512"
          xmlns="http://www.w3.org/2000/svg"
          className="h-full w-full"
        >
          <rect
            width="512"
            height="512"
            x="0"
            y="0"
            rx="30"
            fill="transparent"
            stroke="transparent"
            strokeWidth="0"
            strokeOpacity="100%"
            paintOrder="stroke"
          ></rect>
          <svg
            width="256px"
            height="256px"
            viewBox="0 0 24 24"
            fill="#ffffff"
            x="128"
            y="128"
            role="img"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g fill="#ffffff">
              <path
                fill="currentColor"
                d="M20 8h-5.612l1.123-3.367c.202-.608.1-1.282-.275-1.802S14.253 2 13.612 2H12c-.297 0-.578.132-.769.36L6.531 8H4c-1.103 0-2 .897-2 2v9c0 1.103.897 2 2 2h13.307a2.01 2.01 0 0 0 1.873-1.298l2.757-7.351A1 1 0 0 0 22 12v-2c0-1.103-.897-2-2-2zM4 10h2v9H4v-9zm16 1.819L17.307 19H8V9.362L12.468 4h1.146l-1.562 4.683A.998.998 0 0 0 13 10h7v1.819z"
              />
            </g>
          </svg>
        </svg>
        <div style={{ fontSize: "12px" }}>{like}</div>
        <div style={{ fontSize: "12px", fontStyle: "italic" }}>Like</div>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          textAlign: "center",
          width: "fit-content",
        }}
      >
        <svg
          width="40"
          height="40"
          viewBox="0 0 512 512"
          xmlns="http://www.w3.org/2000/svg"
          className="h-full w-full"
        >
          <rect
            width="512"
            height="512"
            x="0"
            y="0"
            rx="30"
            fill="transparent"
            stroke="transparent"
            strokeWidth="0"
            strokeOpacity="100%"
            paintOrder="stroke"
          ></rect>
          <svg
            width="256px"
            height="256px"
            viewBox="0 0 1024 1024"
            fill="#ffffff"
            x="128"
            y="128"
            role="img"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g fill="#ffffff">
              <path
                fill="currentColor"
                d="M885.9 490.3c3.6-12 5.4-24.4 5.4-37c0-28.3-9.3-55.5-26.1-77.7c3.6-12 5.4-24.4 5.4-37c0-28.3-9.3-55.5-26.1-77.7c3.6-12 5.4-24.4 5.4-37c0-51.6-30.7-98.1-78.3-118.4a66.1 66.1 0 0 0-26.5-5.4H144c-17.7 0-32 14.3-32 32v364c0 17.7 14.3 32 32 32h129.3l85.8 310.8C372.9 889 418.9 924 470.9 924c29.7 0 57.4-11.8 77.9-33.4c20.5-21.5 31-49.7 29.5-79.4l-6-122.9h239.9c12.1 0 23.9-3.2 34.3-9.3c40.4-23.5 65.5-66.1 65.5-111c0-28.3-9.3-55.5-26.1-77.7zM184 456V172h81v284h-81zm627.2 160.4H496.8l9.6 198.4c.6 11.9-4.7 23.1-14.6 30.5c-6.1 4.5-13.6 6.8-21.1 6.7a44.28 44.28 0 0 1-42.2-32.3L329 459.2V172h415.4a56.85 56.85 0 0 1 33.6 51.8c0 9.7-2.3 18.9-6.9 27.3l-13.9 25.4l21.9 19a56.76 56.76 0 0 1 19.6 43c0 9.7-2.3 18.9-6.9 27.3l-13.9 25.4l21.9 19a56.76 56.76 0 0 1 19.6 43c0 9.7-2.3 18.9-6.9 27.3l-14 25.5l21.9 19a56.76 56.76 0 0 1 19.6 43c0 19.1-11 37.5-28.8 48.4z"
              />
            </g>
          </svg>
        </svg>
        <div style={{ fontSize: "12px" }}>{dislike}</div>
        <div style={{ fontSize: "12px", fontStyle: "italic" }}>Dislike</div>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          textAlign: "center",
          width: "fit-content",
        }}
      >
        <svg
          width="40"
          height="40"
          viewBox="0 0 512 512"
          xmlns="http://www.w3.org/2000/svg"
          className="h-full w-full"
        >
          <rect
            width="512"
            height="512"
            x="0"
            y="0"
            rx="30"
            fill="transparent"
            stroke="transparent"
            strokeWidth="0"
            strokeOpacity="100%"
            paintOrder="stroke"
          ></rect>
          <svg
            width="256px"
            height="256px"
            viewBox="0 0 24 24"
            fill="#ffffff"
            x="128"
            y="128"
            role="img"
            xmlns="http://www.w3.org/2000/svg"
          >
            <g fill="#ffffff">
              <g fill="none">
                <path
                  d="M22 10.981L15.027 2v4.99C3.075 6.99 1.711 16.678 2.043 22l.007-.041c.502-2.685.712-6.986 12.977-6.986v4.99L22 10.98z"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </g>
            </g>
          </svg>
        </svg>
        <div style={{ fontSize: "12px" }}>{share}</div>
        <div style={{ fontSize: "12px", fontStyle: "italic" }}>Share</div>
      </div>
    </div>
  )
}
